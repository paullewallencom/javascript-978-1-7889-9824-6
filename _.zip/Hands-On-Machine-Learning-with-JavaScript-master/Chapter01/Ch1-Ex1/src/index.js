import greeting from './greeting';
console.log(greeting(process.argv[2] || 'world'));
