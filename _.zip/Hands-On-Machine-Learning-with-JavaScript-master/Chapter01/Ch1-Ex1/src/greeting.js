const greeting = name => 'Hello, ' + name + '!';
export default greeting;